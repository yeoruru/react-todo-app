import React, { useState } from "react"; //리액트 라이브러리에서 useState 가져온다

//함수형 컴포넌트
export default function App() {

  const [ todoData, setTodoData ] = useState([]);
  const [ value, setValue ] = useState("");

  const btnStyle = {
    color: "#fff",
    border: "none",
    padding: "5px 9px",
    borderRadius:"50%",
    cursor:"pointer",
    float: "right"
  }

  const getStyle = (completed) => {
    return {
      padding:"10px",
      borderBottom: "1px #ccc dotted",
      textDecoration: completed ? "line-through" : "none" //조건부 삼항 연산자 completed가 true 일때 라인스루 아닐때 넌
    }
  }

  // X버튼 이벤트
  const handleClick = (id) => {
    let newTodoData = todoData.filter(data => data.id !== id) // 아이디값이 일치할때 제거 해라
    console.log('newTodoData', newTodoData);
    setTodoData(newTodoData);
  }

  // 인풋에 입력할때 체인지 이벤트 발생
  const handleChange = (e) => {
    console.log('e', e.target.value);
    setValue(e.target.value); //입력한 value 값 넣어줌
  }


  // 입력한값 submit누르면 내용추가 & 입력창 지우기
  const handleSubmit = (e) => {
    // form 안에 input을 전송할 때 페이지 리로드 방지
    e.preventDefault();

    // 새로운 할 일 데이터
    let newTodo = {
      id: Date.now(), //객체
      title: value, // 입력하는 값value 넣어줌
      completed: false, // 할 일 아직 완료되지 않았으니 false
    }

    // 원래 있던 할 일에 새로운 할 일 추가 하고 입력란 글씨 지우기(value: "")
    //setValue({ todoData: [...todoData, newTodo] ,value: ""});
    setTodoData(prev => [...prev, newTodo]);
    setValue("");
  }
  
  // 체크박스로 true/false 값 바꿔주기
  const handelCompletedChange = (id) => { //파라미터를 id로 가져옴
    let newTodoData = todoData.map(data => {
      if(data.id === id) { // 스테이트 안에서 어떤 id가 클릭이 됐는지
        data.completed = !data.completed; //반대로 변경
      }
      return data;
    })
    setTodoData(newTodoData);
  }

    return(
      <div className="container">
        <div className="todoBlock">
          <div className="title">
            <h1>할 일 목록</h1>
          </div>
          
          {todoData.map((data) => //map을 이용해서 배열 내 모든 요소 나열
            <div style={getStyle(data.completed)} key={data.id}> 
              <input type="checkbox" defaultChecked={false} onChange={() => handelCompletedChange(data.id)}/>
              {data.title}
              <button style={btnStyle} onClick={() => handleClick(data.id)}>X</button>
            </div>
          )}

          <form style={{display: 'flex'}} onSubmit={handleSubmit}>
            <input 
              type="text" 
              name="value" 
              style={{flex: '10', padding: '5px'}} 
              placeholder="해야 할 일을 입력하세요." 
              value={value} // 입력하는 값 넣어줌
              onChange={handleChange} // 입력할때 체인지 이벤트 함수
            />
            <input 
              type="submit" 
              value="입력" 
              className="btn" 
              style={{flex: '1'}} 
            />
          </form>
        </div>
      </div>
    )
}