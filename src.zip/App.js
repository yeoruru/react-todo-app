import React from "react"; // 1. 리액트 라이브러리 불러온다

// 2. 함수형 컨포넌트
export default function App() {

  // 4. 리스트 스타일 주기
  const listStyle = {
    padding:"10px",
    borderBottom: "1px #ccc dotted",
    textDecoration: "none"
  }

  // 5. 리스트 배열에 저장
  const todoList = [
    { id:"1", title:"공부하기",completed: true},
    { id:"2", title:"청소하기",completed: false}
  ]

  // 6. filter 메서드를 이용해 X 버튼 클릭 이벤트
  const btnClick = (id) => {
    // 클릭한 버튼의 id 값 일치할때 제거
    let  newTodoList = todoList.filter(data => data.id !== id)

    //console.log('newTodoList', newTodoList);
    // 7. 콘솔로 확인 화면상의 변화는 없어서 리액트의 State 를 이용하여 컴포넌트의 데이터 변화 있는 부분을 리랜더링 해준다
    
  }

  //3. 내용시작
  return(
    <div className="container">
      <div className="todoBlock">
        <div className="title">
          <h1>할 일 목록</h1>
        </div>
        {/* 리스트 시작 */}

        {/* 4. 기존 HTML 처럼 계속 복붙해서 만들 수는 없음 주석처리*/}
        {/* <div style={listStyle}>
          <input type="checkbox" defaultChecked={false}/>
          공부하기
          <button className="btn">X</button>
        </div>
        <div style={listStyle}>
          <input type="checkbox" defaultChecked={false}/>
          청소하기
          <button className="btn">X</button>
        </div> */}

        {/* 5. map() 메서드를 이용해 배열 내의 요소를 함수를 호출한 결과를 모아 새로운 배열을 반환 한다 (고유한 key값 넣어주기) 
        6. filter 메서드를 이용해 X 버튼 onClick 이벤트
        */}

        {todoList.map((data) => 
          <div style={listStyle} key={data.id}>
            <input type="checkbox" defaultChecked={false}/>
            {data.title}
            <button className="btn" onClick={() => btnClick(data.id)}>X</button>
          </div>
        )}
        
      </div>
    </div>

  )
}